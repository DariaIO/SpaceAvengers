import random
import math
import pygame
pygame.init() #initialize our pygame

screen = pygame.display.set_mode((800,500)) #creating our screen and deciding its wedth and length
background=pygame.image.load('R (3).jpg')
pygame.display.set_caption("Space Avenger") #putting a name to our game(title)
icon=pygame.image.load('space.jpg')
pygame.display.set_icon(icon)

playerImg=pygame.image.load('SHIP1.png')
playerX=360
playerY=400
player_change=0

enemyImg = []
enemyX = []
enemyY = []
enemyX_change = []
enemyY_change = []
numberOfEnemies = 5
for i in range(numberOfEnemies):
    enemyImg.append(pygame.image.load('enemyy.png'))
    enemyX.append(random.randint(0,736))
    enemyY.append(random.randint(0,30))
    enemyX_change.append(0.07)
    enemyY_change.append(35)

bulletImg=pygame.image.load('bullett.png')
bulletX=0
bulletY=470
bulletX_change=0
bulletY_change=0.5
bullet_state="ready"

score_value=0
font=pygame.font.Font('freesansbold.ttf',32)
textX=10
textY=10

over_font=pygame.font.Font('freesansbold.ttf',64)

def show_score(x,y):
    score=font.render("score: "+str(score_value),True,(252,252,8))
    screen.blit(score, (x, y))

def game_over_text():
    Over_text= font.render("GAME OVER :(",True, (252, 252, 8))
    screen.blit(Over_text, (350,250))

def player(x,y): #were creating a function
    screen.blit(playerImg,(x,y)) #it basically means to draw and we want to draw our player on screen
def enemy(x,y,i):
    screen.blit(enemyImg[i],(x,y))

def fire_bullet(x,y):
    global bullet_state
    bullet_state="fire"
    screen.blit(bulletImg,(x+16,y))

def iscollision(enemyX,enemyY,bulletX,bulletY):
    distance=math.sqrt(math.pow(enemyX-bulletX,2)+(math.pow(enemyY-bulletY,2)))
    if distance<=27:
        return True
    else:
        return False
running = True
game_over= False
while running:
    screen.fill((0, 0, 0))  # giving the background color RGB(it stands for red,green,blue)
    screen.blit(background,(0,0))

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        if event.type == pygame.KEYDOWN:
          if event.key == pygame.K_RIGHT:
            player_change= 0.1

          if event.key == pygame.K_LEFT:
            player_change=-0.1

          if event.key == pygame.K_SPACE:
            if bullet_state is "ready":
              bulletX=playerX
              fire_bullet(bulletX,bulletY)


        if event.type == pygame.KEYUP:
           if event.key == pygame.K_RIGHT or event.key == pygame.K_LEFT:
              player_change=0

    playerX +=player_change
    if playerX<=0:
        playerX=0
    elif playerX>=736:
        playerX=736
    for i in range(numberOfEnemies):
        if enemyY[i] > 440:
          if not game_over:
             game_over=True
             break

        if game_over:
            for j in range(numberOfEnemies):
                enemyY[j] = 2000
            game_over_text()

        enemyX[i] += enemyX_change[i]
        if enemyX [i]<= 0:
           enemyX_change[i]= 0.07
           enemyY [i]+= enemyY_change[i]
        elif enemyX[i]>= 736:
            enemyX_change[i] = -0.07
            enemyY[i]+=enemyY_change[i]


        Collision=iscollision(enemyX[i],enemyY[i],bulletX,bulletY)
        if Collision:
          bulletY=470
          bullet_state="ready"
          score_value += 1


          enemyX[i] = random.randint(0, 736)
          enemyY[i] = random.randint(0, 30)
        enemy(enemyX[i], enemyY[i], i)

    if bulletY<=0:
        bulletY=470
        bullet_state="ready"

    if bullet_state is "fire":
        fire_bullet(bulletX,bulletY)
        bulletY-=bulletY_change

    player(playerX,playerY)
    show_score(textX,textY)
    pygame.display.update() # this line updates the display and shows the changes that we made on the background in the line 13




